<section class="dark_no_padding" id="dark_no_padding">
        <div class="row" style="margin: 0 auto;">
            <div class="col-12">
                <div class="content_work">
                    <div class="header-center">
                        <h3>Some of my latest work</h3>
                    </div>
                    <ul class="thumbs">
                        <li>
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 1</h4>
                                    <p>Description for sample 1</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 2</h4>
                                    <p>Description for sample 2</p>
                                </div>
                            </a>
                        </li>
                        <li id="tab_hide">
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 3</h4>
                                    <p>Description for sample 3</p>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="more_portfolio">
            <a href="portfolio.php"><button>More</button></a>
        </div>
    </section>