<div class="freelancing_section2">
    <p class="sub_text">I CAN HELP.</p>
    <h3>Let's work together!</h3>
    <p>I am available for freelance projects. If you have a project that you want to get started, think you need my help with something Hire me and get your project done.</p>
    <a href="#"><button>Hire Me</button></a>
</div>