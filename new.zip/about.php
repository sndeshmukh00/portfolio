<?php include 'header.php';?>

<html>
  <head>
      <title>About : Shesh Narayan Deshmukh</title>
      
          <script src="script.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      
  </head>
   
   <body>
    
    
    
    
        <section class="single-section about-area" id="about-area">
        <div class="container">
          <div class="row_about_me">
            <div class="col-12">
              <div class="section-heading">
                <h1 class="section-title">About me</h1>
                <p class="section-description">Get to know me</p>
              </div>
            </div>
          </div>
          <div class="row align-items-center" id="about_content_section" style="margin:0 auto;">
            <!-- Picture part-->
            <div class="col-12 col-lg-5 about-img"><img class="img-fluid img-thumbnail" src="imgs/about_me.jpg" alt="About Picture"></div>
            <!-- Content part-->
            <div class="col-12 col-lg-7 about-content">
              <div class="content-block">
                <h2 class="content-subtitle">Who am I?</h2>
                <h6 class="content-title">I'm Shesh Narayan Deshmukh, an SEO Executive, Web Designer and Web Developer</h6>
                <div class="content-description">
                  <p>I am a freelancer based in the India and I have been doing Search Engine Optimization and building noteworthy websites for years, which comply with the latest design trends. I help convert a vision and an idea into meaningful and useful products. Having a sharp eye for product evolution helps me prioritize tasks, iterate fast and deliver faster.</p>
                </div>
                <address class="content-info">
                  <div class="row">
                    <div class="col-12 col-md-6 single-info"><span>Name:</span>
                      <p>Shesh Narayan Deshmukh</p>
                    </div>
                    <div class="col-12 col-md-6 single-info"><span>Email:</span>
                      <p><a href="mailto:sheshnarayandeshmukh00@gmail.com">snd@sndeshmukh.com</a></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-12 col-md-6 single-info"><span>Age:</span>
                      <p>21</p>
                    </div>
                    <div class="col-12 col-md-6 single-info"><span>From:</span>
                      <p>Bhilai, India</p>
                    </div>
                  </div>
                </address><a id="about_btn" href="#0" ><button style="margin-right: 20px;">Download CV</button></a><a id="about_btn" href="#dark_no_padding" role="button"><button>My Work</button></a>
              </div>
            </div>
          </div>
        </div>
      </section>

    

    <section id="resume_section">

        <div class="resume_container">
            <div style="text-align:center;padding-bottom:80px;">
               <h2>Wait...</h2>
               <p>Here is more about me.</p>
            </div>

            <div class="skill_row">


                <div class="col-md-12">

                    <div id="resume_page_1">

                        <ul class="padding-none" style="justify-content: center; text-align:center;">
                            <li class="d-iflex margin-r-20"><button id="btn_my_education" onclick="hide_div('my_experience');">Education</button></li>
                            <li class="d-iflex"><button id="btn_my_experience" onclick="hide_div('my_education');">Experience</button></li>
                        </ul>

                        <div class="root_content">

                            <div class="root_content_pane">

                                <div id="my_education">

                                    <ul class="root_content_list">

                                        <li>

                                            <span>

                                            </span>

                                            <div class="root_content_media">
                                                <div class="root_content_media_body_1">
                                                    <h4>Class 10</h4>
                                                    <p>Gyandeep Higher Secondary School <br>Gunderdehi (C.G.), India.</p>
                                                </div>
                                            </div>

                                        </li>

                                        <li>

                                            <span>

                                            </span>

                                            <div class="root_content_media">
                                                <div class="root_content_media_body_2">
                                                    <h4>Class 12</h4>
                                                    <p>Gyandeep Higher Secondary School <br>Gunderdehi (C.G.), India.</p>
                                                </div>
                                            </div>

                                        </li>

                                        <li>

                                            <span>

                                            </span>

                                            <div class="root_content_media">
                                                <div class="root_content_media_body_3">
                                                    <h4>Higher Studies</h4>
                                                    <p>Chhatrapati Shivaji Institute of Technology.<br>Durg (C.G.), India.</p>
                                                </div>
                                            </div>

                                        </li>





                                    </ul>

                                </div>

                                <div id="my_experience">

                                    <ul class="root_content_list">

                                        <li>

                                            <span>

                                            </span>

                                            <div class="root_content_media">
                                                <div class="root_content_media_body_1">
                                                    <h4>Web Devloper</h4>
                                                    <p>CSIT Durg<br>(C.G.), India.<br>Since 2019.</p>
                                                </div>
                                            </div>

                                        </li>

                                        <li>

                                            <span>

                                            </span>

                                            <div class="root_content_media">
                                                <div class="root_content_media_body_2">
                                                    <h4>Youtuber</h4>
                                                    <p>Youtube India<br>Since 2014.</p>
                                                </div>
                                            </div>

                                        </li>

                                        <li>

                                            <span>

                                            </span>

                                            <div class="root_content_media">
                                                <div class="root_content_media_body_3">
                                                    <h4>Developer</h4>
                                                    <p>CG-SONGS.COM<br>Durg (C.G.), India.</p>
                                                </div>
                                            </div>

                                        </li>





                                    </ul>

                                </div>

                            </div>

                        </div>



                    </div>
                    <!--
                <div id="resume_page_2">
                    
                    <h2 class="heading">Experience</h2>
                    <div class="resume-wrap d-flex ftco-animate fadeInUp ftco-animated">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <span class="flaticon-ideas"></span>
                        </div>
                        <div class="text pl-3">
                            <span class="date">Since 2019</span>
                            <h2>Web Developer</h2>
                            <span class="position">CSIT Durg.</span>
                            <p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
                        </div>
                    </div>
                    
                </div>
-->
                    <div id="resume_page_3">
                        <br><br>

                        <h1 class="heading">My Technical Skills</h1>
                        <br>
                        <br>
                        <div class="row_skills">
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>HTML</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-2" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width:95%">
                                            <span>95%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>Photoshop</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-1" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:90%">
                                            <span>90%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>CSS</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-3" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width:90%">
                                            <span>90%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>JavaScript</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-4" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:80%">
                                            <span>80%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>WordPress</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-5" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:82%">
                                            <span>82%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>SEO</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-6" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:88%">
                                            <span>88%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>Bootstrap</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-5" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:83%">
                                            <span>83%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 animate-box">
                                <div class="progress-wrap ftco-animate fadeInUp ftco-animated">
                                    <h3>Brackets</h3>
                                    <div class="skill_progress">
                                        <div class="progress_bar color-6" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:93%">
                                            <span>93%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>
    
    
    <?php include 'freelance_sec.php';?>
    <?php include 'some_of_work_no_padding.php';?>
    <?php include 'footer.php';?>
    
   
  <script>
        
        
        /*~~~~~~~~~~~~~~Resume Button Start~~~~~~~~~~~~~~*/
    
    let btn_my_experience = document.querySelector('#btn_my_experience');
    let btn_my_education = document.querySelector('#btn_my_education');
    let my_experience = document.querySelector('#my_experience');
    let my_education = document.querySelector('#my_education');

    
    /*For Education Button Click Start*/
    btn_my_education.addEventListener('click', () => my_education.style.display='block')
    btn_my_education.addEventListener('click', () => my_experience.style.display='none')
    btn_my_education.addEventListener('click', () => btn_my_education.style.backgroundColor='#333')
    btn_my_education.addEventListener('click', () => btn_my_education.style.color='#7fff00')
    btn_my_education.addEventListener('click', () => btn_my_experience.style.color='')
    btn_my_education.addEventListener('click', () => btn_my_education.style.boxShadow='0 0 10px #333,0 0 20px #333,0 0 40px #444')
    btn_my_education.addEventListener('click', () => btn_my_experience.style.boxShadow='none')
    btn_my_education.addEventListener('click', () => btn_my_experience.style.backgroundColor='')
    /*For Education Button Click End*/
    
    /*For Experience Button Click Start*/
    btn_my_experience.addEventListener('click', () => btn_my_experience.style.backgroundColor='#333')
    btn_my_experience.addEventListener('click', () => btn_my_experience.style.boxShadow='0 0 10px #333,0 0 20px #333,0 0 40px #444')
    btn_my_experience.addEventListener('click', () => btn_my_education.style.boxShadow='none')
    btn_my_experience.addEventListener('click', () => btn_my_experience.style.color='#7fff00')
    btn_my_experience.addEventListener('click', () => btn_my_education.style.color='#fff')
    btn_my_experience.addEventListener('click', () => btn_my_education.style.backgroundColor='')
    btn_my_experience.addEventListener('click', () => my_experience.style.display='block')
    btn_my_experience.addEventListener('click', () => my_education.style.display='none')
    /*For Experience Button Click End*/
    
/*~~~~~~~~~~~~~~Resume Button End~~~~~~~~~~~~~~~~*/

    </script>
    
        <script src="https://kit.fontawesome.com/17569c1b4f.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    
   </body>
   </html>