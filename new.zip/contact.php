<?php include 'header.php';?>
   

    <section class="contact_section" >

        <div class="contact_head" style="text-align:center; margin-top:150px; margin-bottom:50px;">

            <h3>Get in Touch</h3>
            <p class="contact_sub_text" style="line-height:0;">Feel free to contact me anytime</p>

        </div>
        <div class="contact_row" style="margin-bottom: 150px;">
            <div class="contact_content">

                <div class="col-12 col-lg-7 message_sidebar">
                    <form class="contact-form" id="contact-form" action="php/contact.php">
                        <h4 class="content-title">Message Me</h4>
                        <div class="row">
                            <div class="col-12 col-md-6 form-group"><input class="form-control" id="contact-name" type="text" name="name" placeholder="Name" required=""></div>
                            <div class="col-12 col-md-6 form-group"><input class="form-control" id="contact-email" type="email" name="email" placeholder="Email" required=""></div>
                            <div class="col-12 form-group"><input class="form-control" id="contact-subject" type="text" name="subject" placeholder="Subject" required=""></div>
                            <div class="col-12 form-group form-message"><textarea class="form-control" id="contact-message" name="message" placeholder="Message" rows="5" required=""></textarea></div>
                            <div class="col-12 form-submit"><button class="btn button-main button-scheme" id="contact-submit" type="submit">Send Message</button>
                                <p class="contact-feedback"></p>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-12 col-lg-5 contact_info_sidebar">
                    <div class="contact_info_content">
                        <div class="contact-info">
                            <h4 class="content-title">Contact Info</h4>
                            <p class="info-description">Always available for freelance work if the right project comes along, Feel free to contact me!</p>
                            <ul class="list-unstyled list-info">
                                <li>
                                    <div>
                                        <span><i class="fas fa-signature"  aria-hidden="true"></i></span>
                                        <div class="content_contact">
                                            <h6>Name</h6>
                                            <p>Shesh Narayan Deshmukh</p>
                                        </div>

                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <span><i class="fas fa-map-marked-alt"  aria-hidden="true"></i></span>
                                        <div class="content_contact">
                                            <h6>Location</h6>
                                            <p>Bhilai (CG), India</p>

                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <span ><i class="fas fa-phone-alt"  aria-hidden="true"></i></span>
                                        <div class="content_contact">

                                            <h6>Call Me</h6>
                                            <p><a href="tel:+917987127900">+91 79871 27900</a></p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <span><i class="fas fa-envelope"  aria-hidden="true"></i></span>

                                        <div class="content_contact">
                                            <h6>Email</h6>
                                            <p><a href="mailto:snd@sndeshmukh.com">snd@sndeshmukh.com</a></p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>






<?php include 'footer.php';?>