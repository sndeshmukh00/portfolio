
      <?php include 'header.php';?> 

          
       <section class="dark_no_padding" id="dark_no_padding" style="border-bottom:none; margin-top:150px;">
        <div class="row" style="margin: 0 auto;">
            <div class="col-12">
                <div class="content_work">
                    <ul class="thumbs">
                        <li>
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 1</h4>
                                    <p>Description for sample 1</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 2</h4>
                                    <p>Description for sample 2</p>
                                </div>
                            </a>
                        </li>
                        <li id="tab_hide">
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 3</h4>
                                    <p>Description for sample 3</p>
                                </div>
                            </a>
                        </li>
                        <li id="tab_hide">
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 3</h4>
                                    <p>Description for sample 3</p>
                                </div>
                            </a>
                        </li>
                        <li id="tab_hide">
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 3</h4>
                                    <p>Description for sample 3</p>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    
   
  
 <?php include 'freelance_sec.php';?> 
 <?php include 'footer.php';?> 