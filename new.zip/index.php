<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shesh Narayan Deshmukh</title>


    <!--    Favicon Start -->
    <link rel="apple-touch-icon" sizes="180x180" href="imgs/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imgs/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imgs/favicon-16x16.png">
    <link rel="manifest" href="imgs/site.webmanifest">

    <!--    Favicon End -->

    <script src="script.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

</head>

<body>


<?php include 'header.php';?>

<!--
    <header>
        <div class="logo"><a href="#"><img src="imgs/logo_2.png" alt=""></a></div>
        <nav>
            <div class="nav_buttons_all">
                <ul>
                    <li><a href="#">about</a></li>
                    <li><a href="#">portfolio</a></li>
                    <li><a href="#">contact</a></li>
                    <li>
                        <ul class="social">

                            <li class="mail" tooltip="Click to send me an email 😀">
                                <a href="mailto:sheshnarayandeshmukh00@gmail.com" title="Send me an Email" target="_blank"><i class="fas fa-envelope"></i></a>
                            </li>
                            <li class="twitter">
                                <a href="http://www.twitter.com/ShanuDeshmukh1" title="Follow me on Twitter" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li class="linkedin">
                                <a href="http://au.linkedin.com/in/" title="Connect with me on Linkedin" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li class="facebook">
                                <a href="http://www.facebook.com/" title="Like me on Facebook" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li class="dribbble">
                                <a href="http://www.dribbble.com/" title="See my Dribbble shots" target="_blank"><i class="fab fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="menu-toggle"><i class="fa fa-bars" aria-hidden="true"></i></div>
    </header>
-->
    <div class="photo_div">
        <div id="parallax_section" class="parallax_sec">


            <img src="imgs/home_1.png" alt="" class="layer" data-speed="-3">
            <img src="imgs/home_2.png" alt="" class="layer" data-speed="5">
            <img src="imgs/home_3.png" alt="" class="layer" data-speed="-5">
            <img src="imgs/home_4.png" alt="" class="layer" data-speed="4">
            <img src="imgs/home_5.png" alt="" class="layer" data-speed="-2">
            <img src="imgs/home_me1.png" alt="" class="layer" data-speed="2">

        </div>
        <div id="parallax_section_mob">
            <img src="imgs/home_me_mob.jpg" alt="">
        </div>

    </div>
    <div style="height: 0;">

        <div class="typing_box_container">
            <div class="type_container">
                <div class="type_box">
                    <div class="auto_typing_area">
                        <h2>I AM <span class="animate_typing"></span></h2>
                    </div>
                </div>

            </div>

        </div>
        <svg>
            <filter id="wavy">
                <feTurbulence x="0" y="0" baseFrequency="0.02" numOctaves="5" seed="2">
                    <animate attributeName="baseFrequency" dur="10s" values="0.02;0.05;0.02" repeatCount="indefinite" />
                </feTurbulence>
                <feDisplacementMap in="SourceGraphic" scale="30"></feDisplacementMap>
            </filter>
        </svg>

    </div>


<?php include 'some_of_work.php';?>
<?php include 'freelance_sec2.php';?>


<!--
    <section class="dark">
        <div class="row" style="margin: 0 auto;">
            <div class="col-12">
                <div class="content_work">
                    <div class="header-center">
                        <h3>Some of my latest work</h3>
                    </div>
                    <ul class="thumbs">
                        <li>
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 1</h4>
                                    <p>Description for sample 1</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 2</h4>
                                    <p>Description for sample 2</p>
                                </div>
                            </a>
                        </li>
                        <li id="tab_hide">
                            <a href="">
                                <img src="http://www.adhamdannaway.com/wp-content/uploads/2014/07/feature-subscriber-notifications.jpg" alt="">
                                <div class="description">
                                    <h4>Sample 3</h4>
                                    <p>Description for sample 3</p>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
-->















<?php include 'footer.php';?>



    <script>
        //menu toggler//
        $(document).ready(function() {
            $('.menu-toggle').click(function() {
                $('div').toggleClass('active')
            });
        });
        //menu toggler end//

        //Automatic typing animation//
        var typed = new Typed(".animate_typing", {
            strings: [
                "SHESH NARAYAN DESHMUKH",
                "A DEVELOPER",
                "A DESIGNER",
                "A PHOTOGRAPHER"
            ],
            typeSpeed: 50,
            backSpeed: 50,
            loop: true
        });
        //Automatic typing animation End//


        //parallax start//
        document.addEventListener('mousemove', parallax);

        function parallax(e) {
            this.querySelectorAll('.layer').forEach(layer => {
                var speed = layer.getAttribute('data-speed')
                var x = (window.innerWidth - e.pageX * speed) / 100
                var y = (window.innerWidth - e.pageY * speed) / 100
                layer.style.transform = ` translateX(${x}px)  translateY(${y}px) `
            })
        }

        //parallax end//
    </script>



</body>

</html>
