<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shesh Narayan Deshmukh</title>


    <!--    Favicon Start -->
    <link rel="apple-touch-icon" sizes="180x180" href="imgs/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imgs/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imgs/favicon-16x16.png">
    <link rel="manifest" href="imgs/site.webmanifest">

    <!--    Favicon End -->

    <script src="script.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

</head>

<body>
    <header>
        <div class="logo"><a href="index.php"><img src="imgs/logo_2.png" alt=""></a></div>
        <nav>
            <div class="nav_buttons_all">
                <ul>
                    <li><a href="about.php">about</a></li>
                    <li><a href="portfolio.php">portfolio</a></li>
                    <li><a href="contact.php">contact</a></li>
                    <li>
                        <ul class="social">

                            <li class="mail" tooltip="Click to send me an email 😀">
                                <a href="mailto:sheshnarayandeshmukh00@gmail.com" title="Send me an Email" target="_blank"><i class="fas fa-envelope"></i></a>
                            </li>
                            <li class="twitter">
                                <a href="http://www.twitter.com/ShanuDeshmukh1" title="Follow me on Twitter" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li class="linkedin">
                                <a href="http://au.linkedin.com/in/" title="Connect with me on Linkedin" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li class="facebook">
                                <a href="http://www.facebook.com/" title="Like me on Facebook" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li class="dribbble">
                                <a href="http://www.dribbble.com/" title="See my Dribbble shots" target="_blank"><i class="fab fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="menu-toggle"><i class="fa fa-bars" aria-hidden="true"></i></div>
    </header>









    <script src="https://kit.fontawesome.com/17569c1b4f.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>





</body>

</html>
